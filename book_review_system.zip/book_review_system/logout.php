<?php
echo "<p align='center'>You are logged out!</p>";;
echo "
<html>
	<head>
	<tile></title>
		<link rel='stylesheet' type='text/css' href='h.css'>
	</head>
		<body background-image='cover.jpg'>
			<div class='header'>
			<p align='center'><table><tr><td colspan='2'><marquee><font size='20' color='white'>Book Review System</font></marquee></td></tr></table></p>
			</div>
			
			<div class='middle_layer'>
			<br>
			<br>
				<ul>
				<li><a href='AdminLogin.html'><b>Administrator</b></a></li>
				<li><a href='PublisherLogin.html'><b>Publisher</b></a></li>
				<li><a href='User_Registration.html'><b>Sign Up</b></a></li>
				<li><a href='User_Login.html'><b>Sign In</b></a></li>
				<li><a href='contact.html'><b>Contact Us</b></a></li>
			</ul>
			</div>
			<div class='footer'>
				<h3 align='center'><a href='about.html'>About Us</a></h3>
			</div>
		</body>
</html>"
?>